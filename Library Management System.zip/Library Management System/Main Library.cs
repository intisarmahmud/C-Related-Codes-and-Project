﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_Management_System
{
    public partial class Main_Library : Form
    {
        public Main_Library()
        {
            InitializeComponent();
        }
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=INTISAR\SQLEXPRESS;Initial Catalog=Library Mangement;Integrated Security=True");

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtbookname.Text != "" && txtvolume.Text != "" && txtauthor.Text!=""&& txtbookcatagory.Text!="")
            {
                SqlCommand s = new SqlCommand("update Library set Catagory=@catagory,Author=@author,Volume=@volume where BookName=@bookname", sqlConnection);
                sqlConnection.Open();
                s.Parameters.AddWithValue("@catagory", txtbookcatagory.Text);
                s.Parameters.AddWithValue("@bookname", txtbookname.Text);
                s.Parameters.AddWithValue("@volume", txtvolume.Text);
                s.Parameters.AddWithValue("@author", txtauthor.Text);
                s.ExecuteNonQuery();
                MessageBox.Show("Update Successfull!!!");
                sqlConnection.Close();

            }
            else
            {
                MessageBox.Show("Please provide all the informations!!!");
            }
        }

        private void btnshowcurrentlibrary_Click(object sender, EventArgs e)
        {
            sqlConnection.Open();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("select* from Library", sqlConnection);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            sqlConnection.Close();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (txtbookname.Text != "" && txtvolume.Text != "" && txtauthor.Text != "" && txtbookcatagory.Text != "")
            {
                SqlCommand s = new SqlCommand("insert into Library(Catagory,BookName,Author,volume) values(@catagory,@bookname,@author,@volume)", sqlConnection);
                sqlConnection.Open();
                s.Parameters.AddWithValue("@catagory", txtbookcatagory.Text);
                s.Parameters.AddWithValue("@bookname", txtbookname.Text);
                s.Parameters.AddWithValue("@author", txtauthor.Text);
                s.Parameters.AddWithValue("@volume", txtvolume.Text);
                s.ExecuteNonQuery();
                sqlConnection.Close();
                MessageBox.Show("Entry Successfull!!!");
            }
            else
            {
                MessageBox.Show("Data Needed!!!");
            }
        }

        private void btnborrow_Click(object sender, EventArgs e)
        {
            if (txtbookname.Text != "")
            {
                SqlCommand s = new SqlCommand("delete Library where BookName=@bookname",sqlConnection);
                sqlConnection.Open();
                s.Parameters.AddWithValue("@bookname",txtbookname.Text );
                s.ExecuteNonQuery();
                sqlConnection.Close();
                MessageBox.Show("Borrowed Successfully!!!");
            }
            else
            {
                MessageBox.Show("Please select Any Book to Borrow!!!");
            }
        }

        private void btnlibrary_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn l = new LogIn();
            l.Show();
        }

        private void tb_search_TextChanged(object sender, EventArgs e)
        {
            sqlConnection.Open();
            SqlCommand c = sqlConnection.CreateCommand();
            c.CommandType = CommandType.Text;

            c.CommandText = "SELECT * from  Library where BookName like '" + txtbookname.Text + "%'";

            c.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(c);
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            sqlConnection.Close();
        }
    }
}
