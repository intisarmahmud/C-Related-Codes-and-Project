﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_Management_System
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=INTISAR\SQLEXPRESS;Initial Catalog=Library Mangement;Integrated Security=True");

        private void btnsignup_Click(object sender, EventArgs e)
        {
            if (txtusername.Text != "" && txtpassword.Text != "" && txtconfirmpassword.Text!="" &&txtfirstname.Text!=""&&txtlastname.Text!="" && txtpassword.Text==txtconfirmpassword.Text)
            {
                SqlCommand s = new SqlCommand("insert into LogIn(Username,Password,ConfirmPassword,FirstName,LastName) values(@username,@password,@confirmpassword,@firstname,@lastname)",sqlConnection);
                sqlConnection.Open();
                s.Parameters.AddWithValue("@username", txtusername.Text);
                s.Parameters.AddWithValue("@password", txtpassword.Text);
                s.Parameters.AddWithValue("@confirmpassword", txtconfirmpassword.Text);
                s.Parameters.AddWithValue("@firstname", txtfirstname.Text);
                s.Parameters.AddWithValue("@lastname", txtlastname.Text);
                s.ExecuteNonQuery();
                sqlConnection.Close();
                MessageBox.Show("Sign up Successfull!!!");
                this.Hide();
                LogIn l = new LogIn();
                l.Show();
            }
            else
            {
                MessageBox.Show("Please Provide Proper Details and Check if Password and Confirm Password Match or Not!!!");
            }
        }
    }
}

