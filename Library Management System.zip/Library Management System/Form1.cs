﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_Management_System
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=INTISAR\SQLEXPRESS;Initial Catalog=Library Mangement;Integrated Security=True");
        private void btnLogIn_Click(object sender, EventArgs e)
        {
            if (txtusername.Text == "" || txtpassword.Text == "")
            {
                MessageBox.Show("Please provide UserName and Password!!!");
                return;
            }
            try
            {
                SqlCommand Command = new SqlCommand("Select * from LogIn where UserName=@username and Password=@password", sqlConnection);
                Command.Parameters.AddWithValue("@Username", txtusername.Text);
                Command.Parameters.AddWithValue("@Password", txtpassword.Text);
                sqlConnection.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(Command);
                DataSet d = new DataSet();
                adapt.Fill(d);
                sqlConnection.Close();
                int count = d.Tables[0].Rows.Count;
                if (count == 1)
                {
                    MessageBox.Show("Login Successful!");
                    this.Hide();
                    Main_Library fm = new Main_Library();
                    fm.Show();
                }
                else
                {
                    MessageBox.Show("User not Found!Please Sign Up or Check UserName/Password!!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnsignup_Click(object sender, EventArgs e)
        {
            
            SignUp s = new SignUp();
            s.Show();
            this.Hide();
        }
    }
}
