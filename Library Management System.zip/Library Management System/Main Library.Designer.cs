﻿
namespace Library_Management_System
{
    partial class Main_Library
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Library));
            this.tb_search = new System.Windows.Forms.TextBox();
            this.lblwelcometolibrary = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtbookcatagory = new System.Windows.Forms.TextBox();
            this.lblbookcatagory = new System.Windows.Forms.Label();
            this.txtauthor = new System.Windows.Forms.TextBox();
            this.lblauthor = new System.Windows.Forms.Label();
            this.btnlibrary = new System.Windows.Forms.Button();
            this.txtvolume = new System.Windows.Forms.TextBox();
            this.lblvolume = new System.Windows.Forms.Label();
            this.lblbookname = new System.Windows.Forms.Label();
            this.txtbookname = new System.Windows.Forms.TextBox();
            this.btnshowcurrentlibrary = new System.Windows.Forms.Button();
            this.btnborrow = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_search
            // 
            this.tb_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb_search.Location = new System.Drawing.Point(243, 16);
            this.tb_search.Multiline = true;
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(416, 24);
            this.tb_search.TabIndex = 0;
            this.tb_search.Text = "Search for Books";
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            // 
            // lblwelcometolibrary
            // 
            this.lblwelcometolibrary.AutoSize = true;
            this.lblwelcometolibrary.BackColor = System.Drawing.Color.Transparent;
            this.lblwelcometolibrary.Font = new System.Drawing.Font("Harlow Solid Italic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwelcometolibrary.Location = new System.Drawing.Point(304, 9);
            this.lblwelcometolibrary.Name = "lblwelcometolibrary";
            this.lblwelcometolibrary.Size = new System.Drawing.Size(297, 40);
            this.lblwelcometolibrary.TabIndex = 1;
            this.lblwelcometolibrary.Text = "Welocme to Library";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SkyBlue;
            this.panel1.Controls.Add(this.tb_search);
            this.panel1.Location = new System.Drawing.Point(-1, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(941, 58);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SkyBlue;
            this.panel2.Controls.Add(this.txtbookcatagory);
            this.panel2.Controls.Add(this.lblbookcatagory);
            this.panel2.Controls.Add(this.txtauthor);
            this.panel2.Controls.Add(this.lblauthor);
            this.panel2.Controls.Add(this.btnlibrary);
            this.panel2.Controls.Add(this.txtvolume);
            this.panel2.Controls.Add(this.lblvolume);
            this.panel2.Controls.Add(this.lblbookname);
            this.panel2.Controls.Add(this.txtbookname);
            this.panel2.Controls.Add(this.btnshowcurrentlibrary);
            this.panel2.Controls.Add(this.btnborrow);
            this.panel2.Controls.Add(this.btnupdate);
            this.panel2.Controls.Add(this.btnadd);
            this.panel2.Location = new System.Drawing.Point(12, 145);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(281, 443);
            this.panel2.TabIndex = 3;
            // 
            // txtbookcatagory
            // 
            this.txtbookcatagory.Location = new System.Drawing.Point(93, 16);
            this.txtbookcatagory.Multiline = true;
            this.txtbookcatagory.Name = "txtbookcatagory";
            this.txtbookcatagory.Size = new System.Drawing.Size(181, 23);
            this.txtbookcatagory.TabIndex = 13;
            // 
            // lblbookcatagory
            // 
            this.lblbookcatagory.AutoSize = true;
            this.lblbookcatagory.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbookcatagory.Location = new System.Drawing.Point(3, 16);
            this.lblbookcatagory.Name = "lblbookcatagory";
            this.lblbookcatagory.Size = new System.Drawing.Size(69, 17);
            this.lblbookcatagory.TabIndex = 12;
            this.lblbookcatagory.Text = "Catagory";
            // 
            // txtauthor
            // 
            this.txtauthor.Location = new System.Drawing.Point(93, 96);
            this.txtauthor.Multiline = true;
            this.txtauthor.Name = "txtauthor";
            this.txtauthor.Size = new System.Drawing.Size(181, 23);
            this.txtauthor.TabIndex = 11;
            // 
            // lblauthor
            // 
            this.lblauthor.AutoSize = true;
            this.lblauthor.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblauthor.Location = new System.Drawing.Point(11, 96);
            this.lblauthor.Name = "lblauthor";
            this.lblauthor.Size = new System.Drawing.Size(57, 17);
            this.lblauthor.TabIndex = 10;
            this.lblauthor.Text = "Author";
            // 
            // btnlibrary
            // 
            this.btnlibrary.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlibrary.Location = new System.Drawing.Point(96, 395);
            this.btnlibrary.Name = "btnlibrary";
            this.btnlibrary.Size = new System.Drawing.Size(75, 27);
            this.btnlibrary.TabIndex = 9;
            this.btnlibrary.Text = "Log Out";
            this.btnlibrary.UseVisualStyleBackColor = true;
            this.btnlibrary.Click += new System.EventHandler(this.btnlibrary_Click);
            // 
            // txtvolume
            // 
            this.txtvolume.Location = new System.Drawing.Point(93, 138);
            this.txtvolume.Multiline = true;
            this.txtvolume.Name = "txtvolume";
            this.txtvolume.Size = new System.Drawing.Size(181, 20);
            this.txtvolume.TabIndex = 8;
            // 
            // lblvolume
            // 
            this.lblvolume.AutoSize = true;
            this.lblvolume.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvolume.Location = new System.Drawing.Point(12, 138);
            this.lblvolume.Name = "lblvolume";
            this.lblvolume.Size = new System.Drawing.Size(56, 17);
            this.lblvolume.TabIndex = 7;
            this.lblvolume.Text = "Volume";
            // 
            // lblbookname
            // 
            this.lblbookname.AutoSize = true;
            this.lblbookname.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbookname.Location = new System.Drawing.Point(3, 56);
            this.lblbookname.Name = "lblbookname";
            this.lblbookname.Size = new System.Drawing.Size(84, 17);
            this.lblbookname.TabIndex = 6;
            this.lblbookname.Text = "Book Name";
            // 
            // txtbookname
            // 
            this.txtbookname.Location = new System.Drawing.Point(93, 56);
            this.txtbookname.Multiline = true;
            this.txtbookname.Name = "txtbookname";
            this.txtbookname.Size = new System.Drawing.Size(181, 23);
            this.txtbookname.TabIndex = 5;
            // 
            // btnshowcurrentlibrary
            // 
            this.btnshowcurrentlibrary.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshowcurrentlibrary.Location = new System.Drawing.Point(44, 324);
            this.btnshowcurrentlibrary.Name = "btnshowcurrentlibrary";
            this.btnshowcurrentlibrary.Size = new System.Drawing.Size(171, 29);
            this.btnshowcurrentlibrary.TabIndex = 4;
            this.btnshowcurrentlibrary.Text = "Show Current Library";
            this.btnshowcurrentlibrary.UseVisualStyleBackColor = true;
            this.btnshowcurrentlibrary.Click += new System.EventHandler(this.btnshowcurrentlibrary_Click);
            // 
            // btnborrow
            // 
            this.btnborrow.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrow.Location = new System.Drawing.Point(177, 255);
            this.btnborrow.Name = "btnborrow";
            this.btnborrow.Size = new System.Drawing.Size(75, 33);
            this.btnborrow.TabIndex = 3;
            this.btnborrow.Text = "Borrow";
            this.btnborrow.UseVisualStyleBackColor = true;
            this.btnborrow.Click += new System.EventHandler(this.btnborrow_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(96, 255);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 33);
            this.btnupdate.TabIndex = 2;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(15, 255);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(75, 33);
            this.btnadd.TabIndex = 1;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(334, 145);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(594, 443);
            this.dataGridView1.TabIndex = 4;
            // 
            // Main_Library
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(940, 609);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblwelcometolibrary);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main_Library";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Library Management";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Label lblwelcometolibrary;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtbookname;
        private System.Windows.Forms.Button btnshowcurrentlibrary;
        private System.Windows.Forms.Button btnborrow;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnlibrary;
        private System.Windows.Forms.TextBox txtvolume;
        private System.Windows.Forms.Label lblvolume;
        private System.Windows.Forms.Label lblbookname;
        private System.Windows.Forms.TextBox txtbookcatagory;
        private System.Windows.Forms.Label lblbookcatagory;
        private System.Windows.Forms.TextBox txtauthor;
        private System.Windows.Forms.Label lblauthor;
    }
}