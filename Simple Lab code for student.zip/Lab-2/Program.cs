﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Your Name:-");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Your Age:-");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name:-" + name +" "+  "Age:-" + age);

        }
    }
}
