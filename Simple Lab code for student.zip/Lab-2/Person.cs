﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Lab2
{
    class Person
    {

    }
}
