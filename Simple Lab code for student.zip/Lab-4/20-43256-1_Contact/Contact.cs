﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Contact
{
    class Contact
    {
        private String PersonName;
        private String PersonID;
        private int Age;
        private String MobileNumber;
        private Char Gender;

        public string personName
        {
            get { return personName; }
            set { personName = value; }
        }
        public string personID
        {
            get { return PersonID; }
            set { personID = value; }
        }
        public int age
        {
            get { return Age; }
            set { Age = value; }
        }
        public string mobileNumber
        {
            get { return MobileNumber; }
            set { MobileNumber = value; }
        }
        public Char gender
        {
            get { return Gender; }
            set { Gender = value; }
        }
        public Contact()
        { }
        public Contact(String PersonName,String PersonID,int Age,String MobileNumber,Char Gender)
        {
            this.personName = PersonName;
            this.personID = PersonID;
            this.age = Age;
            this.mobileNumber = MobileNumber;
            this.gender = Gender;
        }
        public void showPersonalInfo()
        {
            Console.WriteLine("Name:-->" + PersonName + "   " + "ID:-->"+PersonID+"   "+"Age:-->"+Age+"   "+"Mobile Number:-->"+MobileNumber+"    "+"Gender:"+Gender);
        }
        public void DetectMobileOpertator()
        {
            if (MobileNumber[2]==5)
            { Console.WriteLine("Teletalk!!!"); }
            else if (MobileNumber[2]==8)
            { Console.WriteLine("Robi!!!"); }
            else if (MobileNumber[2] == 9)
            { Console.WriteLine("Banglalink!!!"); }
            else if (MobileNumber[2] == 7 && MobileNumber[2]==3)
            { Console.WriteLine("GrameenPhone!!!"); }
            else if (MobileNumber[2] == 6)
            { Console.WriteLine("Airtel!!!"); }
            else 
            { Console.WriteLine("Invalid Operator!!!"); }
        }
        }
    }

