﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Contact
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Contact C = new Contact();
            Console.WriteLine("!!!Welcome To Telecom Center!!!");
            Console.WriteLine("");
            Console.WriteLine("User Name?-->");
            C.personName = Console.ReadLine();
            Console.WriteLine("What is ID?-->");
            C.personID = Console.ReadLine();
            Console.WriteLine("User's Age?-->");
            C.age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Users's Mobile Number?-->");
            C.mobileNumber = Console.ReadLine();
            Console.WriteLine("User's Gender?(M or F)-->");
            C.gender = Convert.ToChar(Console.ReadLine());
            C.showPersonalInfo();
            C.DetectMobileOpertator();
        }
    }
}
