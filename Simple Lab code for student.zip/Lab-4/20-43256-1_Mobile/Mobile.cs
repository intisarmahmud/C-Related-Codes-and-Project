﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Mobile
{
    class Mobile
    {
        private String mobileOwnerName;
        private String mobileNumber;
        private Double mobilebalance;
        private String mobileOSName;
        public int Phone;
        public int amount;
        public Double x;
        public Double timeduration;
        public Double y;
        public String MobileOwnerName
        {
            get { return mobileOwnerName; }
            set { MobileOwnerName = value; }
        }
        public String MobileNumber
        {
            get { return mobileNumber; }
            set { mobileNumber = value; }
        }
        public Double MobileBalance
        {
            get { return mobilebalance; }
            set { mobilebalance = value; }
        }
        public String MobileOSName
        {
            get { return mobileOSName; }
            set { mobileOSName = value; }
        }
        public bool booleanMethod()
        {
            if (Phone == 1)
            {
                Console.WriteLine("Phone is Locked!!!");
                return true;
            }
            else
            {
                Console.WriteLine("Phone is Unlocked!!!");
                return false;
            }
        }
        public Mobile()
            { }
        public Mobile(String MobileOwnerName, String MobileNumber, Double MobileBalance,String MobileOSName,int Phone)
        {
            this.mobileOwnerName = MobileOwnerName;
            this.mobileNumber = MobileNumber;
            this.MobileBalance = MobileBalance;
            this.mobileOSName = MobileOSName;
            this.Phone = Phone;

        }
        public void showinfo()
        {
            Console.WriteLine("Owner Name:::" + mobileOwnerName + "  " + "Mobile Number:::" + mobileNumber + "  " + "Mobile Balane:::" + mobilebalance + "  " + "Mobile OS Name:::" + mobileOSName);
        }
        public void Recharge()
        {
            x = amount + MobileBalance;
            Console.WriteLine("Your New Balance:::-->" + x);
        }
        public void CallSomeone()
        {
            y = timeduration * 1;
            Console.WriteLine("Your Cost:::-->" + y);
        }



       
        


    }
}
