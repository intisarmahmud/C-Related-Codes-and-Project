﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Mobile
{
    class Program
    {
        static void Main(string[] args)
        {
            Mobile M = new Mobile();
            Console.WriteLine("!!!Welcome to Mobile Service!!!!");
            Console.WriteLine("");
            Console.WriteLine("Your name:::");
            M.MobileOwnerName = Console.ReadLine();
            Console.WriteLine("Your Number:::");
            M.MobileNumber = Console.ReadLine();
            Console.WriteLine("Your Balance:::");
            M.MobileBalance = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Your OS :::");
            M.MobileOSName = Console.ReadLine();
            Console.WriteLine("Your phone's lock Status:::");
            M.Phone = Convert.ToInt32(Convert.ToBoolean(Console.ReadLine()));
            M.booleanMethod();
            M.showinfo();
            Console.WriteLine("How much you want to recharge?:::");
            M.amount = Convert.ToInt32(Console.ReadLine());
            M.Recharge();
            Console.WriteLine("Your Call Duration:::");
            M.timeduration = Convert.ToDouble(Console.ReadLine());
            M.CallSomeone();
        }
    }
}
