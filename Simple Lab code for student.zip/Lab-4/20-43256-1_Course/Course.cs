﻿using System;

namespace _20_43256_1_Course
{
    class Course
    {
        private String CourseName;
        private String CourseCode;
        private int CourseCredit;

        public String Coursename
        {
            get { return Coursename; }
            set { CourseName = value; }
        }
        public String Coursecode
        {
            get { return Coursecode; }
            set { CourseCode = value; }
        }
        public int coursecredit
        {
            get { return CourseCredit; }
            set { CourseCredit = value; }
        }
        public Course()
        { }
        public Course(String CourseName, String CourseCode, int CourseCredit)
        {
            this.Coursename = CourseName;
            this.Coursecode = CourseCode;
            this.coursecredit = CourseCredit;
        }
        public void ShowCourseInfo()
        {
            Console.WriteLine("Course Name:-->" + Coursename + " " + "Course Code:-->" + CourseCode + " " + "Course Credit:-->"+CourseCredit);
        }


    }
}
