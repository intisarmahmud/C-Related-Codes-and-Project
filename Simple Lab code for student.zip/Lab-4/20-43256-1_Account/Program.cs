﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Account A = new Account();
            Console.WriteLine("!!!Self Banking :) :D :) !!!");
            Console.WriteLine("What is Account Name??-->");
            A.Accname = Console.ReadLine();
            Console.WriteLine("What is your Account ID??-->");
            A.Acid = Console.ReadLine();
            Console.WriteLine("What is your current Balance?-->");
            A.balance = Convert.ToInt32(Console.ReadLine());
            A.deposit();
            Console.WriteLine("Whom you want to transfer money??-->");
            A.AccountReciever = Console.ReadLine();
            Console.WriteLine("How much you want to Transfer??-->");
            A.amount1 = Convert.ToInt32(Console.ReadLine());
            A.Transfer();
            
            
            A.withdraw();
            
        }
    }
}
