﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Book
{
    class Program
    {
        static void Main(string[] args)
        {
            Book B = new Book();
            Console.WriteLine("!!!!!Welcome top The Book Store!!!!!!");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("What is the Book Name?-->");
            B.bookName = Console.ReadLine();
            Console.WriteLine("Who is the Author?-->");
            B.bookAuthor = Console.ReadLine();
            Console.WriteLine("What is the Book ID?-->");
            B.bookID = Console.ReadLine();
            Console.WriteLine("What is the Book Type?-->");
            B.bookType = Console.ReadLine();
            Console.WriteLine("How Many Copies?-->");
            B.bookCopy = Convert.ToInt32(Console.ReadLine());
            B.showinfo();
            
            Console.WriteLine("How Many Books Do You Want to Add?--> ");
            B.x= Convert.ToInt32(Console.ReadLine());
            B.AddBook();
        }
    }
}
