﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Book
{
    class Book
    {
        private String BookName;
        private String BookAuthor;
        private String BookID;
        private String BookType;
        private int BookCopy;
        public int x;
        public int y;

        public string bookName
        {
            get { return BookName; }
            set { BookName = value; }
        }
        public string bookAuthor
        {
            get { return BookAuthor; }
            set { BookAuthor = value; }
        }
        public string bookID
        {
            get { return BookID; }
            set { BookID = value; }
        }
        public string bookType
        {
            get { return BookType; }
            set { BookType = value; }
        }
        public int bookCopy
        {
            get { return BookCopy; }
            set { BookCopy = value; }
        }
        public Book()
        { }
        public Book(String BookName, String BookAuthor, String BookID, String BookType, int BookCopy)
        {
            this.BookName = BookName;
            this.BookAuthor = BookAuthor;
            this.BookID = BookID;
            this.BookType = BookType;
            this.BookCopy = BookCopy;
        }
        public void showinfo()
        {
            Console.WriteLine("Book Name is:->" + BookName + "     " + "Book Author is:->" + BookAuthor + "     " +"Book ID:->"+BookID+"      "+"Catagory of The Book is:->"+BookType+"      "+"Total Copy of This Book:->"+BookCopy);
        }
        public void AddBook()
        {
            y = BookCopy + x;
            Console.WriteLine("Your Total Book now:::" + y);
        }
        public static int bookCounter()
        {
            Console.WriteLine("Previously Had:-->");
            return 0;
        }
        public static void showTotalBookInfo()
        {
            Console.WriteLine("Prevously had:10 Books");
            Console.WriteLine("Total book Now:");
        }

    }
}
