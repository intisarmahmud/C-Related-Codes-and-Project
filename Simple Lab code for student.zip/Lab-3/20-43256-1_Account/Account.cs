﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Account
{
    class Account
    {
        private String AccName;
        private String ACID;
        private int Balance;
        private int amount;
        public int finalbalance1;
        public int finalbalance2;
        
        public String Accname
        {
            get { return AccName; }
            set { AccName = value; }
        }
        public String Acid
        {
            get { return ACID; }
            set { ACID = value; }
        }
        public int balance
        {
            get { return Balance; }
            set { Balance = value; }
        }
        public void  deposit()
        {
            Console.WriteLine("How much you want to deposit??-->");
            int amount = Convert.ToInt32(Console.ReadLine());
            int finalbalance1 = amount + balance;
            Console.WriteLine("Your Final Balance is:-->"+finalbalance1);
        }
        public void  withdraw()
        {
            if (balance > 0)
            {
                Console.WriteLine("How much you want to withdraw?/-->");
                int amount = Convert.ToInt32(Console.ReadLine());
                int finalbalance2 = finalbalance1 - amount;
                Console.WriteLine("Your Final Balance is:-->" + finalbalance2);
            }
            else
            {
                Console.WriteLine("Insufficient Balance!!!");
            }
        }
    }
}
