﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Course
{
    class Program
    {
        static void Main(string[] args)
        {
            Course C = new Course();
            Console.WriteLine("__!Welcome to the Subject Portal!__");
            Console.WriteLine("What is The course?-->");
            C.Coursename = Console.ReadLine();
            Console.WriteLine("What is the Course Code?-->");
            C.Coursecode = Console.ReadLine();
            Console.WriteLine("How much credit?-->");
            C.coursecredit = Convert.ToInt32(Console.ReadLine());
            C.ShowCourseInfo();
        }
    }
}
