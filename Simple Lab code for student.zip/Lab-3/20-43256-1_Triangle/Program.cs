﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Triangle
{
    class _20_43256_1Triangle
    {
        static void Main(string[] args)
        {

            Triangle T = new Triangle();
            Console.WriteLine("!!!!!!Triangle Checker!!!!!!(Equilateral, Isosceles, Scalene)");

            Console.WriteLine("What is the the value of first side? :-->");
            T.X = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("What is the value of Seconed Side? :-->");
            T.Y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("What is the value of third side? -->");
            T.Z = Convert.ToInt32(Console.ReadLine());
            T.TestTriangle();  
        } 
    }
}
