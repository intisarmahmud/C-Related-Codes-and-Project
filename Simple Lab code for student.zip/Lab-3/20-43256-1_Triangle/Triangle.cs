﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Triangle
{
    class Triangle
    {
        private int x;
        private int y;
        private int z;

        public int X
        {
              get { return x; }
              set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }
        public int Z
        {
            get { return z; }
            set { z = value; }
        }
        public void TestTriangle()
        {
            if (x == y && y == z)
            { Console.WriteLine("It is a Equilateral Triangle!!!"); }
            else if (x == y || y == z || z == x)
            { Console.WriteLine("It is a Isosceles Triangle!!!"); }
            else
            { Console.WriteLine("It is a Scalene Triangle!!!"); }
        }
    }
}
