﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Student
{
    class Program
    {
        static void Main(string[] args)
        {
            Student S = new Student();
            Console.WriteLine("Enter Student's name:");
            S.name = Console.ReadLine();
            Console.WriteLine("Student ID:");
            S.iD = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Student's Department:");
            S.department = Console.ReadLine();
            Console.WriteLine("Student's CGPA:");
            S.cgpa = Convert.ToSingle(Console.ReadLine());
            S.showinfo();

        }
    }
}
