﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_43256_1_Student
{
    class Student
    {
        private String Name;
        private int ID;
        private String Department;
        private float CGPA;

        public String name
        {
            get { return Name; }
            set { Name = value; }
        }
        public int iD
        {
            get{ return ID; }
            set { ID = value; } 
        }
        public String department
        {
            get { return Department; }
            set { Department = value; }
        }
        public float cgpa
        {
            get { return cgpa; }
            set { CGPA = value; }
        }
        public void showinfo()
        {
            Console.WriteLine("Name:" + Name + " " + "ID:" + ID + " " + "Department:" + Department + " " + "CGPA:" + CGPA);
        }

    }
}
